---
title: Ausgangsrechnungserstellung Homeoffice
description: 
published: true
date: 2021-07-16T14:02:18.527Z
tags: 
editor: undefined
dateCreated: 2021-07-16T12:30:11.502Z
---

# Prozessbeschreibung
## Erstellung der Ausgangsrechnung Amt/Kasse
**Sofie**
Die Ausgangsrechnung wird in nmData erstellt und im Büro ausgedruckt. Ggfs. sollte zuvor noch telefonisch oder per Teams geklärt werden, ob genügend Druckerpapier eingelegt ist. Bei Erstellen der Ausgangsrechnung wird parallel eine Tabelle mit den Informationen Rechnungsnummer und zugehörige ER-Nummern für die Einsatzdokumentation ausgefüllt und nach der letzten erstellten Ausgangsrechnung ebenfalls ausgedruckt. 
Kostenübernahmen werden falls möglich mit der Rechnung ausgedruckt, andernfalls wird auf der Ausgangsrechnungsliste vermerkt, welche KÜ angefügt werden muss. 
Private Ausgangsrechnungen werden von Dilay erstellt. 

## Eintüten und versenden der Ausgangsrechnung
**Geschäftsstelle**
Anhand der ausgedruckten Tabelle werden die jeweiligen Einsatzdokumentationen zu den entsprechenden Ausgangsrechnungen sortiert, kuvertiert und für den Versand bereit gemacht. 
Tägliche Prüfung zu Beginn des Tages, ob neue Ausgangsrechnungen im Drucker liegen und diese ggf. in die entsprechende Ablage legen. 