---
title: Schreibtisch
description: Die Startseite von nmData
published: true
date: 2020-02-07T13:19:49.871Z
tags: 
editor: undefined
dateCreated: 2020-02-07T12:57:56.877Z
---

# Schreibtisch
![schreibtisch.png](/schreibtisch.png)
Der Schreibtisch ist die Startseite der Datenbank, sie verschafft einen Überblick über anstehende Tasks und informiert über den Status der Aufträge, für die die aktiven Bearbeiter\*innen zuständig sind. 
