---
title: Einsätze
description: 
published: true
date: 2020-03-04T08:16:41.727Z
tags: 
editor: undefined
dateCreated: 2020-02-07T15:06:24.831Z
---


![überblick.png](/files-einsaetze/überblick.png)
# Überblick
Einsätze regelen die Rahmenbedingungen für die einzelnen [Betreuungspersonen](/betreuer), die in den [Aufträgen](/auftraege) tätig sind. Einsätze sind immer einem Auftrag zugeordnet; ein Auftrag kann beliebig viele Einsätze haben. Das ist dann zum Beispiel wichtig, wenn in einem Auftrag mehrere Betreuungspersonen unterschiedliche Zeiten abdecken. Sind in einem Auftrag beispielsweise täglich 8 Stunden bewilligt, könnte eine Betreuungsperson die Zeiten Montag bis Freitag abdecken und eine weitere Betreuungsperson das Wochenende. Beide BPs würden jeweils einen eigenen Einsatz bekommen, in dem die Bedingungen für ihre Einsatzzeiten geregelt sind.
> Da Einsätze die tatsächlich zu erwartenden gearbeiteten Stunden wiederspiegeln, dienen sie in nmData zur Berechnung aller [Auswertungen](/auswertungen).{.is-info}
# Kopfbereich
![kopfbereich.png](/files-einsaetze/kopfbereich.png)

