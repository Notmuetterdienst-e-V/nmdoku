---
title: Buchungsexport
description: In diesem Abschnitt werden alle Themen rund um den Export von Buchungsdaten zu DATEV beschrieben
published: true
date: 2020-06-02T11:11:07.627Z
tags: 
editor: undefined
dateCreated: 2020-06-02T08:33:55.340Z
---

# Überblick
In diesem Abschnitt finden Sie Informationen zum Export der Buchungsdaten aus nmData hin zu Unternehmen Online. 

## Themen
- [Einrichtung des Datev Belegtransfer-Programms](/verwaltung/export/belegtransfer)
{.links-list}
