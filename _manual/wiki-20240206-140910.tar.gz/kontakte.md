---
title: Kontakte
description: Alle Personen sind in der Datenbank als Kontakte hinterlegt
published: true
date: 2020-02-07T13:19:46.497Z
tags: 
editor: undefined
dateCreated: 2020-02-07T12:57:52.319Z
---

# Kontakte
![überblick_ko.png](/überblick_ko.png)