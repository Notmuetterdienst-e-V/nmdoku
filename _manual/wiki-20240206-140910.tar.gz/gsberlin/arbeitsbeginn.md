---
title: Arbeitsbeginn
description: 
published: true
date: 2021-07-19T08:45:45.369Z
tags: 
editor: undefined
dateCreated: 2021-07-19T08:45:43.345Z
---

# Tasks bei Öffnung der GS morgens
## Alle
### Post
Post vom Vortag aus dem Briefkasten holen und die Ablage entsprechend sortieren.
### Drucker checken
Nachschauen, ob im Drucker neue Ausgangsrechnungen liegen und ggf. in die entsprechende Ablage sortieren.
## Einsatzmanagement
### gemeinsames Emailpostfach checken
- Emails entsprechend der Zuständigkeit markieren oder ggf. weiterleiten (Oli, Sebastian)
- AB Nachrichten abhören und ebenfalls zuordnen, in dringenden Fällen direkt zurückrufen
