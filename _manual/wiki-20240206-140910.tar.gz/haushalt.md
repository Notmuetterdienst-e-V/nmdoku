---
title: Haushalt
description: Haushaltsmodul
published: true
date: 2020-02-07T13:19:41.827Z
tags: 
editor: undefined
dateCreated: 2020-02-07T12:57:43.764Z
---

# Haushalt
![überblick.png](/überblick.png)
Im Haushalt sind alle Informationen zum Ort hinterlegt, an dem die Unterstützung stattfindet. Dies umfasst Personen, die im Haushalt leben oder einen externen Bezug zum Haushalt haben, sowie Daten zum Ort und der Beschaffenheit der Wohnung.